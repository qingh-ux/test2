import { Component } from '@angular/core';


//元件/組件的標籤名是app-page1將這個標籤名貼到app.ts就可以把元件page1套入到app中。
@Component({
  selector: 'app-page1',
  //這是這個元件變成html標籤後的標籤之名，把標籤之名複製去主頁面的ts中的區塊2selector，就可以將組件放進去主頁中
  imports: [],
  templateUrl: './page1.component.html',
  styleUrl: './page1.component.scss'
})

//


export class Page1Component {

}
