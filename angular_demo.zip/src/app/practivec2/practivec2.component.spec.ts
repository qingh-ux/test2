import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Practivec2Component } from './practivec2.component';

describe('Practivec2Component', () => {
  let component: Practivec2Component;
  let fixture: ComponentFixture<Practivec2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Practivec2Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Practivec2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
