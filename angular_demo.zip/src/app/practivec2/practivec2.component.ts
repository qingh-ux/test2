import { Component } from '@angular/core';

@Component({
  selector: 'app-practivec2',
  imports: [],
  templateUrl: './practivec2.component.html',
  styleUrl: './practivec2.component.scss'
})
export class Practivec2Component {

}
