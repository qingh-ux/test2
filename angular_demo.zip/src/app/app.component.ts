import { Practivec2Component } from './practivec2/practivec2.component';
import { Practivec1Component } from './practivec1/practivec1.component';
import { Component, numberAttribute } from '@angular/core';
import { RouterOutlet } from '@angular/router';
//輸入page1的概念核心 第三區的組件名稱 並寫明核心來自哪裡(會自動帶入來源)
// import { Page1Component } from './page1/page1.component';

//第二區
@Component({
  //將組件在ts頁簽中的標籤之名複製過來，讓組件/元件可以在主頁簽中被使用跟呈現。
  selector: 'app-root',
  imports: [
    Practivec1Component,
    Practivec2Component
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})

  //第三區
  export class AppComponent {
    ngOnInit(): void {
      // title: string = "我是標題";
      // content: string = "內容是我";
      // imgSrc: string = "https://www.japaholic.cn/wp-content/uploads/2025/01/image-75.jpeg";

      // msg!: string;
      // msg2!: string;

      // clickBtn(msg: string, msg2: string = 'Ben') {
      //   this.msg = msg;
      //   this.msg2 = msg2;

      // }

      // showAlert() {
      //   alert(this.msg);
      //   alert(this.msg2);


      // }
      //觸發時間點會是在你的網頁一出生的時候
      // ngOninit(): void {
      //   console.log("Allen")
      // }

      // numData = 2;
      // numData2 = 10;

      // ngOninit(): void {
      //   if (this.numData > this.numData2) {
      //     console.log("成立");
      //   } else {
      //     console.log("不成立");
      //   }

      // }

      // ngOnInit(): void {

      //   for (let numData = 1; numData < 51; numData++) {
      //     console.log(numData)
      //   }


      // let numData:Array<string>=[]

      // for (let data of numData)

      //   numData2 = numData.filter((res)
      //   {
      //     return res %= 2;

      //   })



      // let arrayData = [
      //   {
      //     name: '小明',
      //     age: 18
      //   },
      //   {
      //     name: '小陳',
      //     age: 24
      //   },
      //   {
      //     name: '小王',
      //     age: 16
      //   },
      // ]

      // let arrayData2 = arrayData.forEach((age, index, arrayData)
      // {
      //   arrayData[index] = age + '2',


      // }

      // );

      // }


      // let arraydata = [{
      //   userName: "Allen",
      //   payMoney: 500
      // },
      // {
      //   usenName: "Ben",
      //   payMoney: 20
      // },
      // {
      //   userName: "Eric",
      //   payMoney: 120

      // }]




      // userName: string = 'Allen';
      // userMoney1: number = 200;
      // hamgpr: number = 50;
      // fripr: number = 40;
      // cost1: number = 50 * 1 + 40 * 3

      // let userAsst: number = ()
      // {
      //   userAsst = jsonData.userMoney1 - cost1

      // }

      // useName: 'Allen';
      // userMoney2: number = 5000;
      // cost2: number = 50 * 10 + 40 * 10
      // discount: number = 0.9

      // let userAsst2: number = ()
      // {
      //   userAsst2 = JsonData.userMoney2 - cost2
      // }

      // console.log(userAsst1);


      //不停宣告變數就好?
      // let allenPay = 200;
      // let hamburger=50;
      // let fries=40;


      // console.log(200-50-(40*3));


      //

      // //用陣列先開答案欄存放得出的值
      // let ans=[];

      // for (let data of arrayData){
      // if (data.payMoney>200)


      // }


      //寫一個可以帶入身高跟體重的方法來計算BMI在哪個區間

      // let height = 180;
      // let weight = 60;
      // let BMI: number = weight / ((height / 100) * (height / 100));
      // console.log(BMI);

      //BMI(height:number,weight:number){
      //let BMI: number = weight / ((height / 100) * (height / 100));
      //console.log(BMI);
      // if:bmi<18.5){
      //   console.log('體重過輕');
      // }

    }



  }
