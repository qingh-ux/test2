import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Practivec1Component } from './practivec1.component';

describe('Practivec1Component', () => {
  let component: Practivec1Component;
  let fixture: ComponentFixture<Practivec1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Practivec1Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Practivec1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
