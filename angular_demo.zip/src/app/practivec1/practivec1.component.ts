import { Component } from '@angular/core';

@Component({
  selector: 'app-practivec1',
  imports: [],
  templateUrl: './practivec1.component.html',
  styleUrl: './practivec1.component.scss'
})
export class Practivec1Component {

}
