import { ExampleService } from './../@services/example.service';
import { Router } from '@angular/router';
import { Component, inject, Input, output } from '@angular/core';

@Component({
  selector: 'app-second',
  imports: [],
  templateUrl: './second.component.html',
  styleUrl: './second.component.scss'
})


export class SecondComponent {
  // router = inject(Router);
  // //相異注入
  // ExampleService = inject(ExampleService);
  // secondData!:string;
  // @Input() userName!: string;
  // // @Input() userAge!: number;
  // @Input() userEmail!: string;
  // @Input() userAddress!: string;

  userName!: string;
  // @Input() userAge!: number;
  userEmail!: string;
  userAddress!: string;

  // outputEmit = output<string>();
  // 要把資料輸出的寫法

  // returnData() {
  //   this.outputEmit.emit('Eric')
    // this.剛剛宣告的全域變數.emit(我要丟出去的內容)



  // ngOnInit(): void {
  //   // this.secondData=this.ExampleService.serviceData;
  //   this.userName = this.ExampleService.userName;
  //   this.userEmail = this.ExampleService.userEmail;
  //   this.userAddress=this.ExampleService.userAddress;
  // }

  // changePage() {
  //   this.router.navigateByUrl('/first')
  // }

}
