import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})


export class ExampleService {
  // serviceData!: string;
  userName!:string;
  // userAge!:number;
  userEmail!:string;
  userAddress!:string;
  //這裡是大家共用的地方 所以我可以在這裡存一個新的全域變數供大家存取
  constructor() { }
}
