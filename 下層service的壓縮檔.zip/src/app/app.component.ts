import { Component, Input } from '@angular/core';
// import { RouterOutlet, RouterLink, Router } from '@angular/router';
// import { SecondComponent } from './second/second.component';
import { FirstComponent } from './first/first.component';
import { FormsModule } from '@angular/forms';

//組件還沒放好 放好啦!!

@Component({
  selector: 'app-root',
  imports: [FirstComponent, FormsModule],
  // RouterOutlet, RouterLink,SecondComponent,
  // 輸入的有組件1組件2以及繫結!
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  userName!: string;
  userEmail!: string;
  userAddress!: string;

  // title = 'services';

  // userAge!: number;

  // 這是用input連結資料的部分

  // constructor(private router:Router){}

  // changePage(url:string){
  //   this.router.navigateByUrl(url);
  // }

  // showAlert(event:string){
  //   alert(event);
  // }
  // 這是output用的部分

}
