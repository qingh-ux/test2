// import { ExampleService } from './../@services/example.service';
import { Component, Input } from '@angular/core';
// inject
// import { RouterOutlet, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';



@Component({
  selector: 'app-first',
  imports: [FormsModule],
  // RouterOutlet,
  templateUrl: './first.component.html',
  styleUrl: './first.component.scss'
})

export class FirstComponent {
  // router = inject(Router);
  // //相異注入 抓取不是我這頁面的資料就要用相異注入 套件或是等等
  // ExampleService = inject(ExampleService);
  // stringData="Allen";
  @Input() userName!: string;
  // userAge!: number;
  @Input() userEmail!:string;
  @Input() userAddress!:string;

  // changePage() {
    // // this.ExampleService.serviceData=this.stringData;
    // this.ExampleService.userName = this.userName;
    // this.ExampleService.userEmail = this.userEmail;
    // this.ExampleService.userAddress=this.userAddress;
    // // this.router.navigateByUrl('/second');

  // }


}
